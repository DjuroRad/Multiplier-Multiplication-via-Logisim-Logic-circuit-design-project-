1. Turn the clock on
2. Enable ticks
3. Enter desired binary input in a_i and b_it
4. Press the button
5. Enjoy

FSM: I used total of 8 states in order to avoid glitching and make sure it will work without any problems. After execution, previous result will be saved in the output and won't change until multiplication is executed again.
Also, i wasn't able to draw the datapath freehand since it didn't look good at all so i just drew it in logisim separately. It is saved as datapath_PROJECT.circ
Project works, i only didn't do the BONUS part.
